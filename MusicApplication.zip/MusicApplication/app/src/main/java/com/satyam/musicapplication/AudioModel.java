package com.satyam.musicapplication;

import java.io.Serializable;

public class AudioModel implements Serializable {

    String path;
    String title;
    String duration;
    int iconResId;

    public AudioModel(String path,String title,String duration, int iconResId){
        this.path=path;
        this.title=title;
        this.duration=duration;
        this.iconResId=iconResId;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getIconResId() {
        return iconResId;
    }

    public void setIconResId(int iconResId) {
        this.iconResId = iconResId;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

}
