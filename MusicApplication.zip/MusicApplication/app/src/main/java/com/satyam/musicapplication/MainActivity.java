package com.satyam.musicapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    TextView songsTxt, nosongsTxt;
    ArrayList<AudioModel> songsList;
    SearchView searchView;
    MusicListAdapter adapter;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        nosongsTxt= findViewById(R.id.noSongsTxt);
        searchView= findViewById(R.id.searchView);

       songsList = new ArrayList<>();
        adapter = new MusicListAdapter(songsList, getApplicationContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);



        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                filterList(newText);
                return true;
            }
        });


        if (checkPermission()==false){
            requestPermission();
            return;
        }
        String[] projection = {
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DURATION
        };

        String selection = MediaStore.Audio.Media.IS_MUSIC  + " !=0";

        Cursor cursor= getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,projection,selection,null,null);


        while (cursor.moveToNext()){

            int iconView = R.drawable.musicplayer;

            AudioModel songData = new AudioModel(cursor.getString(1),cursor.getString(0),cursor.getString(2),iconView);

            if (new File(songData.getPath()).exists()){
                songsList.add(songData);

            }

            if (songsList.size()==0){
                nosongsTxt.setVisibility(View.VISIBLE);
            }else {
                //recyclerview
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                recyclerView.setAdapter(new MusicListAdapter(songsList, getApplicationContext()));

            }

        }

    }

    private void filterList(String newText) {
        ArrayList<AudioModel> filteredList = new ArrayList<>();

        // Convert the newText to lowercase for case-insensitive filtering
        String query = newText.toLowerCase().trim();

        for (AudioModel song : songsList) {
            // Check if the song title contains the query text
            if (song.getTitle().toLowerCase().contains(query)) {
                filteredList.add(song);
            }
        }

        if (filteredList.isEmpty()) {
            // If the filtered list is empty, show a message
            Toast.makeText(this, "No Data Found", Toast.LENGTH_SHORT).show();
        } else {
            adapter.setFilteredList(filteredList);

        }

        // Update the RecyclerView with the filtered list
        MusicListAdapter adapter = new MusicListAdapter(filteredList, getApplicationContext());
        recyclerView.setAdapter(adapter);
    }


    boolean checkPermission(){
        int result = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE);
        if (result== PackageManager.PERMISSION_GRANTED){
            return true;

        }
        else {
            return false;

        }
    }

    void  requestPermission(){

       if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)){

           Toast.makeText(MainActivity.this, "Please Allow Permission", Toast.LENGTH_SHORT).show();
       }
       else {
           ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},123);
       }
    }

}